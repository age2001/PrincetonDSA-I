/* *****************************************************************************
 *  Name:              Alan Enriquez
 *  Last modified:     October 24, 2023
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
